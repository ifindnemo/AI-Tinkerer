# Car Neuron · pitch film (3:30) · brag plan

**Angle.** "A warning light only knows about the car." The film is the narrated spine of the AI Tinkerer talk: slides 1, 3 and 4 of the timetable. Slide 2 (live demo, 3:00) and the wrap-up are presented live.
**Overrides of the brag defaults (user request).** Duration 210 s instead of 15–25 s. Voice: Blaze, speaker BTV Helen (`UK-Nu-1-TM`, model `v2.0_pro`, speed 1.0, English) instead of Kokoro. Tone: cinematic, calm, technical.
**Kept from brag.** Grounded claims only, readable pacing (every line holds for its narration), music ducked under voice, scene length follows the generated audio, one hook, a real-UI/real-code scene in every part.

## Structure (pause points for the presenter)

| Part | Abs time | Slide | Content |
|---|---|---|---|
| 1 | 0–30 s | What I Built | Problem (lamp vs driver) → Car Neuron reveal → blackbox + webcam → one agent → "same fault, different advice" |
| 2 | 30–120 s | Under the Hood | Browser sensing and privacy schema (422 on extra field) → safety rules → Guardian in Python and TypeScript → agent and tools → plan matrix → Blaze voice and robot |
| 3 | 120–210 s | Challenges & Learnings | Speed → noise → model vs rules → small things → trade-off → next → "Let rules guard. Let the model explain." |

Each part ends in a silent hold of about 2 s with music faded out, so the presenter can stop the file there and go to the next slide or the live demo. The MP4 is also cut per part.

## Grounding
Every number and code excerpt comes from the repository: thresholds 105/120 °C, 1.5 s / 2.5 s eye closure, 15 records per batch, `DriverEvent` with `extra="forbid"`, `COOLANT_CRITICAL_C`, `_enforce_safety_floor`, `guardian_cases.json` (13 cases), plan matrix in `plan.py`, `_claim` keys, Blaze 425, navigation 0.2 s → 10 s on software WebGL. Simulated data is labelled "illustrative demo scenario" on every frame.

## Music
Sascha Ende (CC BY 4.0): vol-12 (part 1, beat-locked reveal at 8.74 s), vol-1 (part 2), vol-9 (part 3). Volume lanes keep music under 0.16–0.30 and fade it out before each pause point. Audio-reactive visuals were skipped on purpose: the soundtrack is narration-led and the ducked music has no clear peaks worth tracking.

"""Round-trip each narration clip through Blaze STT and diff against the script (catches mispronounced terms)."""
import difflib, json, re, sys, time
from pathlib import Path

BACKEND = Path("/home/nemo/code/Testing/AI-Tinkerer-fe/backend")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(BACKEND))
from dotenv import dotenv_values
from stt import BlazeSTT

env = dotenv_values(BACKEND / ".env")
script = json.loads((HERE / "script.json").read_text())
timing = json.loads((HERE / "durations.json").read_text())
norm = lambda s: re.findall(r"[a-z0-9']+", s.lower())
with BlazeSTT(token=env["BLAZE_API_TOKEN"].strip(), language="en", base_url=(env.get("BLAZE_BASE_URL") or "https://api.blaze.vn").strip(), timeout=60.0) as stt:
    for part in script["parts"]:
        for line in part["lines"]:
            if line["id"] <= "p1-05": continue
            path = HERE / "clips" / timing[line["id"]]["file"]
            for attempt in range(6):
                try:
                    heard = stt.transcribe(path.read_bytes(), filename=path.name, content_type="audio/mpeg")
                    break
                except Exception as error:  # 429: wait and retry
                    time.sleep(4 * (attempt + 1))
            else:
                print(line["id"], "STT unavailable"); continue
            time.sleep(1.5)
            a, b = norm(line["text"]), norm(heard)
            ratio = difflib.SequenceMatcher(None, a, b).ratio()
            print(f"{line['id']} {ratio:.2f}  heard: {heard}" if ratio < 0.97 else f"{line['id']} {ratio:.2f}", flush=True)

"""Synthesize the narration with Blaze (BTV Helen). Keys stay in backend/.env and are never printed.
Usage: backend/.venv/bin/python synth.py   (re-runs reuse clips/ by a hash of the text)"""
import hashlib, json, subprocess, sys
from pathlib import Path

BACKEND = Path("/home/nemo/code/Testing/AI-Tinkerer-fe/backend")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(BACKEND))
from dotenv import dotenv_values
from voice import BlazeTTS  # noqa: E402

env = dotenv_values(BACKEND / ".env")
SPEAKER, MODEL, SPEED = "UK-Nu-1-TM", "v2.0_pro", 1.0
script = json.loads((HERE / "script.json").read_text())
clips = HERE / "clips"
clips.mkdir(exist_ok=True)
timing = {}
with BlazeTTS(token=env["BLAZE_API_TOKEN"].strip(), speaker_id=SPEAKER, model=MODEL, language="en", audio_format="mp3",
              audio_speed=SPEED, base_url=(env.get("BLAZE_BASE_URL") or "https://api.blaze.vn").strip(), timeout=90.0) as tts:
    for part in script["parts"]:
        for line in part["lines"]:
            key = hashlib.sha1(f"{SPEAKER}|{MODEL}|{SPEED}|{line['text']}".encode()).hexdigest()[:12]
            path = clips / f"{line['id']}-{key}.mp3"
            if not path.exists():
                for old in clips.glob(f"{line['id']}-*.mp3"):
                    old.unlink()
                path.write_bytes(tts.synthesize(line["text"]).audio)
            seconds = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)]).decode())
            timing[line["id"]] = {"file": path.name, "seconds": round(seconds, 3), "words": len(line["text"].split())}
            print(f"{line['id']}: {seconds:5.2f}s  {timing[line['id']]['words']:3d} words", flush=True)
(HERE / "durations.json").write_text(json.dumps(timing, indent=1))

"""Place the narration clips on the 210 s timeline: timing.json, one voiceover mp3 per part, captions."""
import json, re, subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
COMP = HERE.parent / "composition"
script = json.loads((HERE / "script.json").read_text())
dur = json.loads((HERE / "durations.json").read_text())
LEAD, GAP = 0.5, {"p1": 0.3, "p2": 0.5, "p3": 0.45}
timing = {"parts": {}}
for part in script["parts"]:
    t = part["start"] + LEAD
    lines = []
    for line in part["lines"]:
        d = dur[line["id"]]["seconds"]
        lines.append({"id": line["id"], "start": round(t, 2), "end": round(t + d, 2), "file": dur[line["id"]]["file"], "text": line["text"]})
        t += d + GAP[part["id"]]
    last = lines[-1]["end"]
    timing["parts"][part["id"]] = {"start": part["start"], "end": part["end"], "speechEnd": last, "hold": round(part["end"] - last, 2), "lines": lines}
    print(part["id"], "speech ends", last, "hold", round(part["end"] - last, 2))
(HERE / "timing.json").write_text(json.dumps(timing, indent=1))

# One mp3 per part (positions relative to the part start), so the composition has three audio clips.
(COMP / "assets" / "voice").mkdir(parents=True, exist_ok=True)
for pid, part in timing["parts"].items():
    inputs, filters, labels = [], [], []
    for i, line in enumerate(part["lines"]):
        inputs += ["-i", str(HERE / "clips" / line["file"])]
        ms = int(round((line["start"] - part["start"]) * 1000))
        filters.append(f"[{i}:a]aresample=44100,aformat=channel_layouts=mono,adelay={ms}:all=1[a{i}]")
        labels.append(f"[a{i}]")
    graph = ";".join(filters) + ";" + "".join(labels) + f"amix=inputs={len(labels)}:normalize=0:duration=longest,apad=whole_dur={part['end'] - part['start']}[out]"
    target = COMP / "assets" / "voice" / f"vo-{pid}.mp3"
    subprocess.check_call(["ffmpeg", "-y", "-v", "error", *inputs, "-filter_complex", graph, "-map", "[out]", "-t", str(part["end"] - part["start"]), "-b:a", "160k", str(target)])
    print(target.name, subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(target)]).decode().strip())

def sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?:;])\s+", text) if s.strip()]

def stamp(sec):
    h, rem = divmod(sec, 3600); m, s = divmod(rem, 60)
    return f"{int(h):02d}:{int(m):02d}:{s:06.3f}"

vi = json.loads((HERE / "captions.vi.json").read_text()) if (HERE / "captions.vi.json").exists() else {}
for lang in ("en", "vi"):
    if lang == "vi" and not vi:
        continue
    cues = ["WEBVTT", ""]
    for part in timing["parts"].values():
        for line in part["lines"]:
            parts = sentences(line["text"])
            texts = parts if lang == "en" else vi[line["id"]]
            assert len(texts) == len(parts), f"{line['id']}: {len(texts)} vs {len(parts)} sentences"
            weights = [len(x) for x in parts]
            span, t = line["end"] - line["start"], line["start"]
            for text, w in zip(texts, weights):
                share = span * w / sum(weights)
                cues += [f"{stamp(t)} --> {stamp(t + share)}", text, ""]
                t += share
    (HERE / f"captions.{lang}.vtt").write_text("\n".join(cues))
print("captions written")

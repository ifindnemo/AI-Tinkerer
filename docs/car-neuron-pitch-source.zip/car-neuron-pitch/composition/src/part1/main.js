// Part 1 · What I built (0–30 s). Narration: p1-01 0.5, p1-02 3.58, p1-03 6.57, p1-04 10.23, p1-05 17.59, p1-06 23.43.
ambient(tl, R, 30);
railFill(tl, R, 0, 30);
var hud = q(R, ".hud"), rail = q(R, ".rail");
var A = q(R, "#p1-a"), B = q(R, "#p1-b"), C = q(R, "#p1-c"), D = q(R, "#p1-d");

/* ---------- A · the lamp knows the car, not the driver (0–6.9) ---------- */
tl.set(A, { opacity: 1 }, 0);
tl.to(A, { opacity: 0, duration: 0.4, ease: "power2.in" }, 6.5);
tl.fromTo(q(R, "#p1-a-kick"), { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 0.15);
var h1 = splitWords(q(R, "#p1-h1")), h2 = splitWords(q(R, "#p1-h2"));
wordsIn(tl, h1, 0.5, 0.3, 0.6);
tl.to(h1, { yPercent: -118, opacity: 0, duration: 0.4, ease: "power3.in", stagger: 0.03 }, 3.3);
wordsIn(tl, h2, 3.62, 0.3, 0.6);
tl.fromTo(q(R, "#p1-gauge"), { y: 70, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: "power3.out" }, 0.2);
countTo(tl, q(R, "#p1-temp"), 92, 105, 0.6, 3.4, function (v) { return String(Math.round(v)); }, "sine.inOut");
tl.fromTo(q(R, "#p1-fill"), { scaleX: 0.24 }, { scaleX: 0.5, duration: 2.8, ease: "sine.inOut" }, 0.6);
tl.fromTo(q(R, "#p1-driver"), { y: 70, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: "power3.out" }, 3.55);
var eyeL = q(R, "#p1-face-a .eye-l"), eyeR = q(R, "#p1-face-a .eye-r");
tl.to(eyeL, { scaleY: 0.06, svgOrigin: "158 197", duration: 1.9, ease: "power1.in" }, 4.3);
tl.to(eyeR, { scaleY: 0.06, svgOrigin: "242 197", duration: 1.9, ease: "power1.in" }, 4.3);
countTo(tl, q(R, "#p1-secs"), 0, 2.6, 4.3, 6.3, function (v) { return v.toFixed(1); }, "none");
var ok = q(R, "#p1-pill-ok"), warn = q(R, "#p1-pill-warn"), crit = q(R, "#p1-pill-crit");
tl.fromTo(ok, { opacity: 0, y: 8 }, { opacity: 1, y: 0, duration: 0.4, ease: "power2.out" }, 4.0);
tl.set(ok, { opacity: 0 }, 5.4); tl.fromTo(warn, { opacity: 0, scale: 0.9 }, { opacity: 1, scale: 1, duration: 0.3, ease: "back.out(2)" }, 5.4);
tl.set(warn, { opacity: 0 }, 6.2); tl.fromTo(crit, { opacity: 0, scale: 0.9 }, { opacity: 1, scale: 1, duration: 0.3, ease: "back.out(2)" }, 6.2);

/* ---------- B · brand (6.3–10.4) ---------- */
tl.set(B, { opacity: 1 }, 6.3);
tl.set(B, { opacity: 0 }, 10.4);
tl.to([hud, rail], { opacity: 0, duration: 0.25, ease: "power2.in" }, 6.3);
tl.fromTo(q(R, "#p1-b-iris"), { clipPath: "circle(0% at 50% 50%)" }, { clipPath: "circle(112% at 50% 50%)", duration: 0.9, ease: "power3.inOut" }, 6.3);
var strokes = qa(q(R, "#p1-b-mark"), "path, circle[stroke-width]");
strokes.forEach(function (s, i) { drawPath(tl, s, 6.75 + i * 0.07, 0.8, "power2.inOut"); });
tl.fromTo(qa(q(R, "#p1-b-mark"), "circle[stroke='none']"), { opacity: 0, scale: 0.2, transformOrigin: "50% 50%" }, { opacity: 1, scale: 1, duration: 0.4, ease: "back.out(2.4)", stagger: 0.08 }, 7.5);
tl.fromTo(q(R, "#p1-b-word"), { y: 50, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: "power4.out" }, 6.8);
tl.fromTo(q(R, "#p1-b-kick"), { opacity: 0, x: -24 }, { opacity: 1, x: 0, duration: 0.5, ease: "power3.out" }, 7.45);
var tag = splitWords(q(R, "#p1-b-tag"));
wordsIn(tl, tag, 8.25, 0.22, 0.55);
// beat-locked: 8.74s (strong cue in vol-12): the car arrives
tl.fromTo(q(R, "#p1-b-car"), { x: 360, opacity: 0 }, { x: 0, opacity: 1, duration: 0.95, ease: "power3.out" }, 8.74);
tl.to(q(R, "#p1-b-car"), { x: -26, duration: 1.2, ease: "sine.inOut" }, 9.7);
tl.to(q(R, "#p1-b-iris"), { clipPath: "circle(0% at 50% 50%)", duration: 0.55, ease: "power3.in" }, 9.95);
tl.to(qa(B, "#p1-b-mark, #p1-b-word, #p1-b-kick, #p1-b-tag, #p1-b-car"), { opacity: 0, duration: 0.3, ease: "power2.in" }, 9.95);
tl.to([hud, rail], { opacity: 1, duration: 0.3, ease: "power2.out" }, 10.1);

/* ---------- C · two senses, one agent (10.2–23.4) ---------- */
tl.fromTo(C, { opacity: 0 }, { opacity: 1, duration: 0.3 }, 10.2);
tl.to(C, { opacity: 0, duration: 0.4, ease: "power2.in" }, 23.0);
tl.fromTo(q(R, "#p1-bb"), { y: 60, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: "power3.out" }, 10.3);
var tickAt = [10.7, 11.7, 12.7, 13.7, 14.7, 15.7, 16.7];
var vals = {
  "#p1-r1": ["2,180", "2,230", "2,205", "2,260", "2,310", "2,290", "2,340"],
  "#p1-r2": ["65 km/h", "66 km/h", "66 km/h", "67 km/h", "68 km/h", "68 km/h", "69 km/h"],
  "#p1-r3": ["39 %", "41 %", "41 %", "43 %", "44 %", "46 %", "47 %"],
  "#p1-r4": ["100 °C", "101 °C", "102 °C", "103 °C", "104 °C", "105 °C", "106 °C"],
  "#p1-r5": ["96 °C", "97 °C", "97 °C", "98 °C", "98 °C", "99 °C", "99 °C"]
};
Object.keys(vals).forEach(function (sel) {
  var cell = q(R, sel);
  tickAt.forEach(function (t, i) {
    tl.set(cell, { textContent: vals[sel][i] }, t);
    tl.fromTo(cell, { opacity: 0.25 }, { opacity: 1, duration: 0.35, ease: "power2.out" }, t);
  });
});
var wires = ["#p1-w1", "#p1-w2", "#p1-w3"].map(function (s) { return q(R, s); });
var flows = ["#p1-f1", "#p1-f2", "#p1-f3"].map(function (s) { return q(R, s); });
drawPath(tl, wires[0], 11.0, 0.9);
tl.fromTo(q(R, "#p1-cam"), { y: 60, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: "power3.out" }, 13.5);
drawPath(tl, wires[1], 14.0, 0.9);
qa(q(R, "#p1-cam"), ".p1-signals .chip").forEach(function (chip, i) { tl.fromTo(chip, { opacity: 0, x: -20 }, { opacity: 1, x: 0, duration: 0.4, ease: "power3.out" }, 14.5 + i * 0.35); });
// the agent and its answer are sketched as placeholders first, then fill in as the narration reaches them
tl.fromTo(q(R, "#p1-node"), { opacity: 0 }, { opacity: 0.55, duration: 0.6, ease: "power2.out" }, 10.7);
tl.set(q(R, "#p1-node-mark"), { opacity: 0.18 }, 10.7);
tl.fromTo(q(R, "#p1-out"), { opacity: 0, y: 40 }, { opacity: 0.5, y: 0, duration: 0.7, ease: "power3.out" }, 10.9);
tl.set(qa(q(R, "#p1-out"), ".blk"), { opacity: 0 }, 10.9);
tl.to(q(R, "#p1-node"), { opacity: 1, borderColor: "rgba(29,117,82,0.55)", duration: 0.5, ease: "power2.out" }, 17.3);
tl.fromTo(q(R, "#p1-node"), { scale: 0.9 }, { scale: 1, duration: 0.7, ease: "back.out(1.8)" }, 17.3);
tl.to(q(R, "#p1-node-mark"), { opacity: 1, duration: 0.5 }, 17.3);
tl.set(q(R, "#p1-node"), { borderStyle: "solid" }, 17.3);
tl.fromTo(q(R, "#p1-node-l"), { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 17.7);
tl.to(q(R, "#p1-out"), { opacity: 1, duration: 0.6, ease: "power2.out" }, 19.0);
drawPath(tl, wires[2], 18.9, 0.5);
tl.fromTo(q(R, "#p1-blk1"), { y: 24, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, ease: "power3.out" }, 19.7);
tl.fromTo(q(R, "#p1-blk2"), { y: 24, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, ease: "power3.out" }, 21.6);
flows.forEach(function (f, i) {
  tl.fromTo(f, { opacity: 0, strokeDashoffset: 0 }, { opacity: 0.9, duration: 0.3 }, [11.8, 14.9, 19.4][i]);
  tl.to(f, { strokeDashoffset: -420, duration: 23 - [11.8, 14.9, 19.4][i], ease: "none" }, [11.8, 14.9, 19.4][i]);
});

/* ---------- D · same fault, different advice (23.3–30) ---------- */
tl.fromTo(D, { opacity: 0 }, { opacity: 1, duration: 0.3 }, 23.3);
var d1 = splitWords(q(R, "#p1-dh1")), d2 = splitWords(q(R, "#p1-dh2"));
wordsIn(tl, d1, 23.5, 0.18, 0.6);
wordsIn(tl, d2, 24.35, 0.2, 0.6);
tl.fromTo(q(R, ".p1-d-same"), { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 25.0);
tl.fromTo(q(R, "#p1-dl"), { y: 70, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: "power3.out" }, 25.5);
tl.fromTo(q(R, "#p1-dr"), { y: 70, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: "power3.out" }, 26.4);
tl.to([q(R, "#p1-dl"), q(R, "#p1-dr")], { y: -8, duration: 3, ease: "sine.inOut", yoyo: true, repeat: 0 }, 27.0);

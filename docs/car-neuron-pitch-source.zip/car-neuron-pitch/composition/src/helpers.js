/* Shared helpers, inlined into every part by build.py. Pure functions of timeline time: no clocks, no randomness. */
function q(root, sel) { return root.querySelector(sel); }
function qa(root, sel) { return Array.prototype.slice.call(root.querySelectorAll(sel)); }

/* Split an element's text into masked word spans so words can slide up one by one. Returns the inner spans. */
function splitWords(el) {
  var parts = el.textContent.trim().split(/\s+/);
  el.textContent = "";
  return parts.map(function (word, i) {
    var outer = document.createElement("span");
    outer.className = "w";
    var inner = document.createElement("span");
    inner.className = "wi";
    inner.textContent = word;
    outer.appendChild(inner);
    el.appendChild(outer);
    if (i < parts.length - 1) el.appendChild(document.createTextNode(" "));
    return inner;
  });
}

/* A scene fades in at `a` and out at `b` (it stays hidden outside). */
function sceneWindow(tl, el, a, b, fade) {
  fade = fade == null ? 0.4 : fade;
  tl.fromTo(el, { opacity: 0 }, { opacity: 1, duration: fade, ease: "power2.out" }, a);
  tl.to(el, { opacity: 0, duration: fade, ease: "power2.in" }, b - fade);
}

/* Words slide up from behind a mask. */
function wordsIn(tl, words, at, stagger, dur) {
  tl.fromTo(words, { yPercent: 118, opacity: 0 }, { yPercent: 0, opacity: 1, duration: dur || 0.55, ease: "power4.out", stagger: stagger == null ? 0.07 : stagger }, at);
}

/* A number rolls from `from` to `to` between a and b. `fmt` builds the text. */
function countTo(tl, el, from, to, a, b, fmt, ease) {
  var state = { v: from };
  el.textContent = fmt(from);
  tl.to(state, { v: to, duration: b - a, ease: ease || "power2.out", onUpdate: function () { el.textContent = fmt(state.v); } }, a);
}

/* Draws an SVG path from nothing to full length. */
function drawPath(tl, path, at, dur, ease) {
  var len = path.getTotalLength();
  gsap.set(path, { strokeDasharray: len, strokeDashoffset: len });
  tl.to(path, { strokeDashoffset: 0, duration: dur, ease: ease || "power2.inOut" }, at);
}

/* The progress rail: the segment of the running part fills over its length. */
function railFill(tl, root, index, duration) {
  qa(root, ".rail .seg").forEach(function (seg, i) {
    if (i < index) { tl.set(seg.querySelector("u"), { scaleX: 1 }, 0); }
    if (i === index) { seg.className += " on"; tl.fromTo(seg.querySelector("u"), { scaleX: 0 }, { scaleX: 1, duration: duration, ease: "none" }, 0); }
  });
}

/* Slow ambient drift for the background glows. */
function ambient(tl, root, duration) {
  tl.fromTo(q(root, ".glow.a"), { x: 0, y: 0, scale: 1 }, { x: 140, y: 90, scale: 1.12, duration: duration, ease: "sine.inOut" }, 0);
  tl.fromTo(q(root, ".glow.b"), { x: 0, y: 0, scale: 1 }, { x: -120, y: -70, scale: 1.1, duration: duration, ease: "sine.inOut" }, 0);
  tl.fromTo(q(root, ".dots"), { x: 0, y: 0 }, { x: -64, y: -32, duration: duration, ease: "none" }, 0);
}

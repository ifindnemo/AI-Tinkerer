// Part 2 · Under the hood (local 0–90 s = abs 30–120). Narration starts: p2-01 0.5, p2-02 14.73, p2-03 26.58, p2-04 38.77, p2-05 49.44, p2-06 65.93, p2-07 81.55.
ambient(tl, R, 90);
railFill(tl, R, 1, 90);
var hud = q(R, ".hud");
var pills = qa(R, "#p2-track span");
function stage(key, at) {
  pills.forEach(function (p) {
    var on = p.getAttribute("data-k") === key;
    tl.to(p, { backgroundColor: on ? "#1d7552" : "rgba(29,117,82,0)", color: on ? "#ffffff" : "#58645e", borderColor: on ? "#1d7552" : "#c3ccc4", duration: 0.35, ease: "power2.out" }, at);
  });
}
function win(id, a, b) { var el = q(R, id); tl.fromTo(el, { opacity: 0 }, { opacity: 1, duration: 0.35, ease: "power2.out" }, a); tl.to(el, { opacity: 0, duration: 0.35, ease: "power2.in" }, b - 0.35); return el; }
function pop(sel, at, dy) { tl.fromTo(q(R, sel), { y: dy == null ? 50 : dy, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: "power3.out" }, at); }

/* ---------- A · the map (0–14.9) ---------- */
win("#p2-a", 0, 14.9);
stage("browser", 0.2);
tl.fromTo(q(R, "#p2-track"), { opacity: 0, y: -10 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 0.2);
tl.fromTo(q(R, "#p2-a-c1"), { opacity: 0 }, { opacity: 1, duration: 0.5 }, 1.6);
pop("#p2-bs", 2.0); pop("#p2-camc", 2.9);
var cells = qa(R, "#p2-cells i");
cells.forEach(function (c, i) { tl.to(c, { backgroundColor: "#1d7552", borderColor: "#1d7552", duration: 0.2, ease: "power2.out" }, 4.4 + i * 0.26); });
tl.fromTo(q(R, ".p2-x15"), { opacity: 0, x: -24 }, { opacity: 1, x: 0, duration: 0.6, ease: "power3.out" }, 7.6);
tl.fromTo(q(R, "#p2-sim"), { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 10.4);
// the rest of the map is sketched early, then solidifies when the narration says it is real
var srv = ["#p2-s1", "#p2-s2", "#p2-s3", "#p2-s4", "#p2-s5"].map(function (s) { return q(R, s); });
var outs = [q(R, "#p2-o1"), q(R, "#p2-o2")];
tl.fromTo(q(R, "#p2-a-c2"), { opacity: 0 }, { opacity: 1, duration: 0.5 }, 3.6);
tl.fromTo(q(R, "#p2-a-c3"), { opacity: 0 }, { opacity: 1, duration: 0.5 }, 3.8);
tl.fromTo(q(R, "#p2-proxy"), { opacity: 0 }, { opacity: 1, duration: 0.5 }, 3.8);
tl.fromTo(srv.concat(outs), { opacity: 0, y: 24 }, { opacity: 0.32, y: 0, duration: 0.5, ease: "power2.out", stagger: 0.1 }, 3.8);
["#p2-w1", "#p2-w2", "#p2-w3", "#p2-w4"].forEach(function (id, i) { var p = q(R, id); drawPath(tl, p, 4.2 + i * 0.3, 0.6); tl.fromTo(p, { opacity: 0 }, { opacity: 0.35, duration: 0.3 }, 4.2 + i * 0.3); });
tl.to(srv.concat(outs), { opacity: 1, duration: 0.5, ease: "power2.out", stagger: 0.12 }, 12.2);
tl.to([q(R, "#p2-w1"), q(R, "#p2-w2"), q(R, "#p2-w3"), q(R, "#p2-w4")], { opacity: 1, duration: 0.4 }, 12.2);
["#p2-f1", "#p2-f2", "#p2-f3", "#p2-f4"].forEach(function (id) {
  var f = q(R, id);
  tl.fromTo(f, { opacity: 0, strokeDashoffset: 0 }, { opacity: 0.9, duration: 0.3 }, 12.4);
  tl.to(f, { strokeDashoffset: -240, duration: 2.5, ease: "none" }, 12.4);
});
tl.to(q(R, "#p2-a-c2"), { opacity: 0, duration: 0.3 }, 12.1);
tl.fromTo(q(R, "#p2-real"), { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 12.4);

/* ---------- B · privacy (14.5–26.4) ---------- */
win("#p2-b", 14.5, 26.4);
stage("browser", 14.6);
tl.fromTo(q(R, "#p2-bc1"), { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 15.2);
pop("#p2-json", 17.2, 40);
tl.fromTo(q(R, "#p2-py"), { y: 40, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: "power3.out" }, 19.4);
tl.fromTo(q(R, "#p2-bc2"), { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 21.3);
tl.set(q(R, "#p2-comma"), { opacity: 1 }, 20.5);
tl.to(q(R, "#p2-extra"), { height: 42, opacity: 1, duration: 0.45, ease: "power3.out" }, 20.5);
tl.to(q(R, "#p2-forbid"), { backgroundColor: "rgba(126,226,176,0.16)", duration: 0.4 }, 22.8);
tl.fromTo(q(R, "#p2-stamp"), { opacity: 0, scale: 1.8, rotation: -8 }, { opacity: 1, scale: 1, rotation: -5, duration: 0.35, ease: "power4.in" }, 23.5);
tl.fromTo(q(R, "#p2-bc3"), { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 23.9);
tl.to(q(R, "#p2-extra"), { opacity: 0.35, duration: 0.5 }, 24.0);

/* ---------- C · rules set the floor (26.3–38.6) ---------- */
win("#p2-c", 26.3, 38.6);
stage("rules", 26.4);
pop("#p2-safety", 27.0);
tl.to(q(R, "#p2-hl1"), { backgroundColor: "rgba(126,226,176,0.16)", duration: 0.4 }, 33.4);
var ladderParts = [q(R, "#p2-sn"), q(R, "#p2-sw"), q(R, "#p2-sc")];
tl.fromTo(ladderParts, { opacity: 0, x: 40 }, { opacity: 1, x: 0, duration: 0.5, ease: "power3.out", stagger: 0.25 }, 31.0);
tl.fromTo(q(R, "#p2-lcap"), { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 35.0);
pop("#p2-floor", 35.2);
tl.fromTo(q(R, "#p2-llm"), { opacity: 0, x: 60 }, { opacity: 1, x: 0, duration: 0.5, ease: "power3.out" }, 35.6);
tl.fromTo(q(R, "#p2-fl"), { scaleX: 0 }, { scaleX: 1, duration: 0.5, ease: "power3.out" }, 36.3);
tl.fromTo(q(R, "#p2-fl-tag"), { opacity: 0 }, { opacity: 1, duration: 0.4 }, 36.5);
tl.to(q(R, "#p2-llm"), { y: -170, backgroundColor: "#b8382a", duration: 0.55, ease: "back.out(1.4)" }, 36.9);
tl.set(q(R, "#p2-llm"), { textContent: "Result: critical" }, 37.0);
tl.to(q(R, "#p2-hl2"), { backgroundColor: "rgba(126,226,176,0.16)", duration: 0.4 }, 36.8);

/* ---------- D · one policy, written twice (38.5–49.3) ---------- */
win("#p2-d", 38.5, 49.3);
stage("guardian", 38.6);
pop("#p2-gpy", 39.2);
pop("#p2-gts", 41.9);
pop("#p2-cases", 44.2);
for (var k = 1; k <= 6; k++) {
  var row = q(R, "#p2-k" + k);
  tl.fromTo(row, { opacity: 0, x: -20 }, { opacity: 1, x: 0, duration: 0.35, ease: "power3.out" }, 44.6 + (k - 1) * 0.45);
  tl.fromTo(row.querySelector("em"), { scale: 0 }, { scale: 1, duration: 0.3, ease: "back.out(3)" }, 44.8 + (k - 1) * 0.45);
}

/* ---------- E · the agent and its tools (49.2–65.8) ---------- */
win("#p2-e", 49.2, 65.8);
stage("agent", 49.3);
pop("#p2-stack", 49.7);
pop("#p2-prompt", 53.2);
[56.0, 57.5, 59.2, 60.7].forEach(function (t, i) {
  tl.fromTo(q(R, "#p2-t" + (i + 1)), { x: 70, opacity: 0 }, { x: 0, opacity: 1, duration: 0.6, ease: "power3.out" }, t);
});
tl.to(q(R, "#p2-pend"), { scale: 1.06, duration: 0.6, ease: "sine.inOut", yoyo: true, repeat: 3 }, 62.6);

/* ---------- F · the plan: car × driver (65.7–81.4) ---------- */
win("#p2-f", 65.7, 81.4);
stage("plan", 65.8);
tl.fromTo(qa(R, "#p2-matrix .p2-mh"), { opacity: 0 }, { opacity: 1, duration: 0.4, stagger: 0.12 }, 66.4);
tl.fromTo([q(R, "#p2-c11"), q(R, "#p2-c12")], { y: 40, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, ease: "power3.out", stagger: 0.15 }, 67.0);
tl.fromTo([q(R, "#p2-c21"), q(R, "#p2-c22")], { y: 40, opacity: 0 }, { y: 0, opacity: 0.55, duration: 0.6, ease: "power3.out", stagger: 0.15 }, 68.4);
pop("#p2-plancode", 69.0, 40);
tl.set(q(R, "#p2-c11"), { className: "p2-cell hot-g" }, 70.8);
tl.fromTo(q(R, "#p2-c11"), { scale: 0.97 }, { scale: 1, duration: 0.5, ease: "back.out(2)" }, 70.8);
tl.set(q(R, "#p2-c12"), { className: "p2-cell hot-w" }, 74.4);
tl.fromTo(q(R, "#p2-c12"), { scale: 0.97 }, { scale: 1, duration: 0.5, ease: "back.out(2)" }, 74.4);
tl.to(q(R, "#p2-c11"), { opacity: 0.5, duration: 0.4 }, 74.4);
pop("#p2-uiline", 75.6, 30);
tl.to(q(R, "#p2-hlp1"), { backgroundColor: "rgba(126,226,176,0.16)", duration: 0.4 }, 78.2);
tl.to(q(R, "#p2-c12 small"), { color: "#9a5f0c", fontWeight: 700, duration: 0.4 }, 78.3);

/* ---------- G · voice and robot (81.3–90) ---------- */
tl.fromTo(q(R, "#p2-g"), { opacity: 0 }, { opacity: 1, duration: 0.35 }, 81.3);
stage("voice", 81.4);
pop("#p2-bubble", 81.8, 40);
var say = splitWords(q(R, "#p2-say"));
tl.fromTo(say, { opacity: 0.12 }, { opacity: 1, duration: 0.3, ease: "power1.out", stagger: 0.19 }, 82.3);
tl.fromTo(q(R, "#p2-robot"), { scale: 0.7, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.7, ease: "back.out(1.6)" }, 85.0);
tl.fromTo(q(R, "#p2-robot-l"), { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 85.6);
tl.to(q(R, "#p2-halo"), { scale: 1.12, duration: 0.45, ease: "sine.inOut", yoyo: true, repeat: 9 }, 85.2);
tl.to(q(R, "#p2-mouth"), { attr: { d: "M150 280Q210 292 270 280" }, duration: 0.22, ease: "sine.inOut", yoyo: true, repeat: 17 }, 85.4);

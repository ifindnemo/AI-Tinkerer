// Part 3 · Challenges & learnings (local 0–90 s = abs 120–210). Narration starts: p3-01 0.5, p3-02 9.28, p3-03 14.72, p3-04 26.57, p3-05 41.18, p3-06 55.41, p3-07 66.37, p3-08 72.91, p3-09 83.16.
ambient(tl, R, 90);
railFill(tl, R, 2, 90);
var pills = qa(R, "#p3-track span");
function stage(key, at) {
  pills.forEach(function (p) {
    var on = p.getAttribute("data-k") === key;
    tl.to(p, { backgroundColor: on ? "#1d7552" : "rgba(29,117,82,0)", color: on ? "#ffffff" : "#58645e", borderColor: on ? "#1d7552" : "#c3ccc4", duration: 0.35, ease: "power2.out" }, at);
  });
}
function win(id, a, b) { var el = q(R, id); tl.fromTo(el, { opacity: 0 }, { opacity: 1, duration: 0.35, ease: "power2.out" }, a); tl.to(el, { opacity: 0, duration: 0.35, ease: "power2.in" }, b - 0.35); return el; }
function pop(sel, at, dy, o) { tl.fromTo(q(R, sel), { y: dy == null ? 50 : dy, opacity: 0 }, { y: 0, opacity: o == null ? 1 : o, duration: 0.7, ease: "power3.out" }, at); }
tl.fromTo(q(R, "#p3-track"), { opacity: 0, y: -10 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 0.2);

/* ---------- A · speed (0–14.9) ---------- */
win("#p3-a", 0, 14.9);
stage("speed", 0.3);
tl.fromTo(q(R, "#p3-a-n"), { opacity: 0, x: -20 }, { opacity: 1, x: 0, duration: 0.5, ease: "power3.out" }, 0.5);
tl.fromTo(q(R, "#p3-big"), { y: 60, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: "power4.out" }, 1.4);
tl.fromTo(q(R, "#p3-bigl"), { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.6, ease: "power3.out" }, 3.2);
pop("#p3-chart", 1.8, 50);
tl.fromTo(q(R, "#p3-ll1"), { opacity: 0 }, { opacity: 1, duration: 0.4 }, 2.4);
tl.fromTo(q(R, "#p3-b1"), { scaleX: 0 }, { scaleX: 1, duration: 4.6, ease: "power1.inOut" }, 2.6);
tl.fromTo(q(R, "#p3-ll2"), { opacity: 0 }, { opacity: 1, duration: 0.4 }, 9.5);
tl.fromTo(q(R, "#p3-b2"), { scaleX: 0 }, { scaleX: 1, duration: 0.7, ease: "power3.out" }, 10.0);
tl.fromTo(q(R, "#p3-fn1"), { opacity: 0, y: 8 }, { opacity: 1, y: 0, duration: 0.4 }, 10.6);
tl.fromTo(q(R, "#p3-b3"), { scaleX: 0 }, { scaleX: 1, duration: 0.9, ease: "power2.out" }, 12.2);
tl.fromTo(q(R, "#p3-fn2"), { opacity: 0, y: 8 }, { opacity: 1, y: 0, duration: 0.4 }, 12.8);
tl.to(q(R, "#p3-b1"), { opacity: 0.4, duration: 0.6 }, 9.6);

/* ---------- B · noise (14.5–26.5) ---------- */
win("#p3-b", 14.5, 26.5);
stage("noise", 14.6);
pop("#p3-before", 15.0);
["#p3-c1", "#p3-c2", "#p3-c3", "#p3-c4", "#p3-c5"].forEach(function (id, i) {
  tl.fromTo(q(R, id), { x: -60, opacity: 0 }, { x: 0, opacity: 1, duration: 0.45, ease: "power3.out" }, 15.9 + i * 0.7);
});
pop("#p3-claim", 20.2, 40);
tl.to(q(R, "#p3-hl1"), { backgroundColor: "rgba(126,226,176,0.16)", duration: 0.4 }, 21.4);
pop("#p3-now", 21.0, 40);
tl.fromTo(q(R, "#p3-n1"), { scaleX: 0, transformOrigin: "0 50%" }, { scaleX: 1, duration: 0.5, ease: "power3.out" }, 21.7);
tl.fromTo(q(R, "#p3-ch1"), { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 22.0);
tl.fromTo(q(R, "#p3-n2"), { opacity: 0 }, { opacity: 0.55, duration: 0.4 }, 23.2);
tl.fromTo(q(R, "#p3-n3"), { y: -30, opacity: 0 }, { y: 0, opacity: 1, duration: 0.45, ease: "back.out(2)" }, 23.8);
tl.to(q(R, "#p3-n2"), { width: 120, duration: 0.4, ease: "power2.in" }, 24.3);
tl.fromTo(q(R, "#p3-ch2"), { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 24.0);

/* ---------- C · rules vs model (26.5–41) ---------- */
win("#p3-c", 26.5, 41.0);
stage("rules", 26.6);
pop("#p3-n-a", 29.6, 40);
// the other two stages are sketched first, then fill in as the story reaches them
tl.fromTo([q(R, "#p3-n-b"), q(R, "#p3-n-c"), q(R, "#p3-ar1"), q(R, "#p3-ar2")], { opacity: 0 }, { opacity: 0.22, duration: 0.5 }, 30.2);
tl.to(q(R, "#p3-ar1"), { opacity: 1, duration: 0.5 }, 31.0);
tl.to(q(R, "#p3-n-b"), { opacity: 1, y: 0, duration: 0.6, ease: "power3.out" }, 31.5);
tl.to(q(R, "#p3-ar2"), { opacity: 1, duration: 0.5 }, 35.0);
tl.to(q(R, "#p3-n-c"), { opacity: 1, duration: 0.6, ease: "power3.out" }, 35.6);
tl.fromTo(q(R, "#p3-xx"), { scale: 0 }, { scale: 1, duration: 0.4, ease: "back.out(3)" }, 37.2);
pop("#p3-fix", 38.2, 40);
tl.to(q(R, "#p3-hl2"), { backgroundColor: "rgba(126,226,176,0.16)", duration: 0.4 }, 39.4);
pop("#p3-result", 39.4, 40);
tl.to([q(R, "#p3-n-a"), q(R, "#p3-n-b"), q(R, "#p3-n-c"), q(R, "#p3-ar1"), q(R, "#p3-ar2")], { opacity: 0.45, duration: 0.5 }, 38.2);

/* ---------- D · small things (41–55.3) ---------- */
win("#p3-d", 40.9, 55.3);
stage("small", 41.0);
pop("#p3-bug1", 43.0, 50);
tl.fromTo(qa(R, "#p3-bug1 .fix"), { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 47.2);
pop("#p3-bug2", 49.6, 50);
tl.fromTo(qa(R, "#p3-bug2 .fix"), { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 52.6);

/* ---------- D2 · robot beside the 3D car (55–66.3) ---------- */
win("#p3-d2", 54.9, 66.3);
stage("small", 55.0);
tl.fromTo(q(R, "#p3-gpun"), { opacity: 0, y: 50 }, { opacity: 1, y: 0, duration: 0.7, ease: "power4.out" }, 56.0);
countTo(tl, q(R, "#p3-gn1"), 0.2, 0.2, 56.0, 56.1, function (v) { return v.toFixed(1) + " s"; });
tl.fromTo(q(R, "#p3-gn2"), { opacity: 0, scale: 0.6, transformOrigin: "0 50%" }, { opacity: 1, scale: 1, duration: 0.6, ease: "back.out(1.8)" }, 57.2);
tl.fromTo(q(R, "#p3-gpul"), { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 57.8);
pop("#p3-scene3d", 56.6, 40);
tl.to(q(R, "#p3-rob"), { y: -10, rotation: 6, duration: 0.35, ease: "sine.inOut", yoyo: true, repeat: 7 }, 58.0);
pop("#p3-note", 62.0, 40);

/* ---------- E · trade-off (66.2–72.8) ---------- */
win("#p3-e", 66.1, 72.9);
stage("trade", 66.2);
pop("#p3-o1", 67.0, 40, 0.8);
pop("#p3-o2", 68.6, 40);
tl.fromTo(q(R, "#p3-fixrow"), { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 70.2);

/* ---------- F · next (72.8–83.2) ---------- */
win("#p3-f", 72.7, 83.3);
stage("next", 72.8);
pop("#p3-x1", 73.4, 40); pop("#p3-x2", 76.4, 40); pop("#p3-x3", 79.6, 40);

/* ---------- G · lesson (83.1–90) ---------- */
tl.fromTo(q(R, "#p3-g"), { opacity: 0 }, { opacity: 1, duration: 0.4 }, 83.0);
stage("lesson", 83.1);
var l1 = splitWords(q(R, "#p3-l1a")), l2 = splitWords(q(R, "#p3-l1b"));
wordsIn(tl, l1, 83.6, 0.25, 0.65);
wordsIn(tl, l2, 85.2, 0.3, 0.65);
tl.fromTo(q(R, "#p3-lmark"), { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.6, ease: "power3.out" }, 86.6);
tl.fromTo(q(R, "#p3-credit"), { opacity: 0 }, { opacity: 1, duration: 0.6 }, 87.2);

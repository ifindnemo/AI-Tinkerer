#!/usr/bin/env python3
"""Builds compositions/part{1,2,3}.html from src/: shared.css + helpers.js inlined into each sub-composition
(a templated sub-composition is transported alone, so it cannot link to shared files)."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE / "src"
PARTS = {
    1: {"id": "p1", "comp": "part1", "duration": 30, "chapter": "What I built"},
    2: {"id": "p2", "comp": "part2", "duration": 90, "chapter": "Under the hood"},
    3: {"id": "p3", "comp": "part3", "duration": 90, "chapter": "Challenges &amp; learnings"},
}
MARK = ('<svg class="mark" viewBox="2 15 44 23" fill="none" stroke="#1d7552" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        '<path d="M5.6 30.6H8.4M17.6 30.6H30.4M39.6 30.6H42.4C43.8 30.6 44.6 29.5 44.2 28.2L43.7 26.6C43.2 25.1 41.9 24.1 40.3 23.9L35 23.1C31.6 20.1 27.4 18.4 22.9 18.4C19.3 18.4 16.4 19.4 13.8 21.2L8.6 23.9C5.6 25 3.6 27 3.6 29C3.6 29.9 4.5 30.6 5.6 30.6Z" stroke-width="3"/>'
        '<circle cx="13" cy="30.6" r="4.1" stroke-width="3"/><circle cx="35" cy="30.6" r="4.1" stroke-width="3"/>'
        '<path d="M23.6 24.4L16 28.4M23.6 24.4L32.2 28.4" stroke-width="2.2"/>'
        '<circle cx="23.6" cy="24.4" r="3.1" fill="#1d7552" stroke="none"/><circle cx="13" cy="30.6" r="1.5" fill="#1d7552" stroke="none"/><circle cx="35" cy="30.6" r="1.5" fill="#1d7552" stroke="none"/></svg>')


def build(n: int) -> None:
    meta = PARTS[n]
    folder = SRC / f"part{n}"
    root = f"{meta['id']}-root"
    css = (SRC / "shared.css").read_text() + "\n" + (folder / "style.css").read_text()
    css = css.replace("#ROOT", f"#{root}")
    chrome = f'''
    <div class="bg" data-layout-ignore><div class="dots"></div><div class="glow a"></div><div class="glow b"></div></div>'''
    hud = f'''
    <div class="hud" data-layout-allow-overflow><div class="left">{MARK}<span class="chapter"><b>●</b>{meta["chapter"]}</span></div><span class="tag" style="font-size:19px">Car Neuron · illustrative demo scenario</span></div>
    <div class="rail"><div class="seg s1"><i><u></u></i>What I built</div><div class="seg s2"><i><u></u></i>Under the hood</div><div class="seg s3"><i><u></u></i>Challenges &amp; learnings</div></div>'''
    body = (folder / "body.html").read_text()
    js = (SRC / "helpers.js").read_text() + "\n" + (folder / "main.js").read_text()
    html = f'''<!doctype html>
<html lang="en"><head><meta charset="UTF-8"></head><body>
<template>
<style>
{css}
</style>
<div id="{root}" data-composition-id="{meta["comp"]}" data-width="1920" data-height="1080" data-duration="{meta["duration"]}">
{chrome}
{body}
{hud}
</div>
<script>
(function () {{
var R = document.getElementById("{root}");
var tl = gsap.timeline({{ paused: true }});
{js}
window.__timelines["{meta["comp"]}"] = tl;
}})();
</script>
</template></body></html>
'''
    (HERE / "compositions").mkdir(exist_ok=True)
    (HERE / "compositions" / f"{meta['comp']}.html").write_text(html)
    print("built", meta["comp"], len(html) // 1024, "KB")


if __name__ == "__main__":
    for n in PARTS:
        if (SRC / f"part{n}" / "main.js").exists():
            build(n)

# Car Neuron pitch film (3:30)
Source of `frontend/public/film/car-neuron-pitch-210s.mp4`. See docs/intro-film-pitch-210s.md in the repository.
Music files (Sascha Ende, ende.app, CC BY 4.0: happy-beats-business-moves vol-1, vol-9, vol-12) are not bundled: put them in `composition/assets/music/` under the names `index.html` references. Edit `composition/src/`, run `python3 composition/build.py`, then `npx hyperframes@0.8.146 check` and `render` (Node 22+).
`voice/synth.py` needs a Blaze token in `backend/.env` of the repository; the finished voice mp3 files are in `composition/assets/voice/`.
